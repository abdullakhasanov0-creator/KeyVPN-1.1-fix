package com.keyvpn.app.data

import com.keyvpn.app.core.Fmt
import com.keyvpn.app.core.LinkParser
import com.keyvpn.app.core.Parsed
import java.net.HttpURLConnection
import java.net.URL

object Subscriptions {
    class Fetched(val servers: List<Parsed>, val title: String?, val info: String?)

    fun fetch(url: String): Fetched {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "KeyVPN/1.0")
            val code = c.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            val body = c.inputStream.use { it.readBytes() }.take(5_000_000).toByteArray().toString(Charsets.UTF_8)
            var title = c.getHeaderField("profile-title")
            if (title != null && title.startsWith("base64:")) {
                title = LinkParser.decodeBase64(title.removePrefix("base64:"))?.toString(Charsets.UTF_8)
            }
            val info = Fmt.userInfo(c.getHeaderField("subscription-userinfo"))
            return Fetched(LinkParser.parseAny(body), title?.takeIf { it.isNotBlank() }, info)
        } finally {
            c.disconnect()
        }
    }
}
