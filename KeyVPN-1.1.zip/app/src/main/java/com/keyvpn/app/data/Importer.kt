package com.keyvpn.app.data

import com.keyvpn.app.AppScope
import com.keyvpn.app.core.LinkParser
import com.keyvpn.app.core.Links
import com.keyvpn.app.core.Sub
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Импорт ключей / подписок из текста (вставка, QR, deep-link, «Поделиться»). */
object Importer {
    class Result(val added: Int, val message: String)

    suspend fun import(text: String): Result = withContext(Dispatchers.IO) {
        val t = text.trim()
        if (t.isEmpty()) return@withContext Result(0, "Пусто — вставьте ключ или ссылку подписки")
        if (t.startsWith("happ://crypt", true)) {
            return@withContext Result(0, "Зашифрованные ссылки happ://crypt не поддерживаются. Используйте обычную ссылку подписки или ключ.")
        }
        val url = Links.subscriptionUrl(t)
        if (url != null) {
            val f = try { Subscriptions.fetch(url) } catch (e: Exception) {
                return@withContext Result(0, "Не удалось загрузить подписку: ${e.message ?: "ошибка сети"}")
            }
            if (f.servers.isEmpty()) return@withContext Result(0, "В подписке нет поддерживаемых ключей")
            val id = Links.sha1(url)
            Store.upsertSub(Sub(id, url, f.title ?: Links.hostOf(url), System.currentTimeMillis(), f.info))
            Store.replaceSub(id, f.servers)
            autoTest()
            return@withContext Result(f.servers.size, "Подписка добавлена: ${f.servers.size} серверов")
        }
        val parsed = LinkParser.parseAny(t)
        if (parsed.isEmpty()) return@withContext Result(0, "Ключ не распознан (поддерживаются vless, vmess, trojan, ss)")
        val added = Store.add(parsed, null)
        autoTest()
        Result(added.size, if (added.isEmpty()) "Такой ключ уже добавлен" else "Добавлено серверов: ${added.size}")
    }

    suspend fun refresh(sub: Sub): Boolean = withContext(Dispatchers.IO) {
        try {
            val f = Subscriptions.fetch(sub.url)
            if (f.servers.isEmpty()) return@withContext false
            Store.upsertSub(sub.copy(title = f.title ?: sub.title, updatedAt = System.currentTimeMillis(), info = f.info))
            Store.replaceSub(sub.id, f.servers)
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun refreshStale(maxAgeMs: Long) {
        val now = System.currentTimeMillis()
        for (s in Store.subs.value) if (now - s.updatedAt > maxAgeMs) refresh(s)
    }

    suspend fun refreshAll() { for (s in Store.subs.value) refresh(s) }

    /** Автотест: сразу после добавления проверяем только ещё не тестированные серверы. */
    private fun autoTest() {
        AppScope.scope.launch { PingTester.testAll(Store.servers.value.filter { it.testedAt == 0L }) }
    }
}
