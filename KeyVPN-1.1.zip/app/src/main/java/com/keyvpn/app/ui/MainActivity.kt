package com.keyvpn.app.ui

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.keyvpn.app.AppScope
import com.keyvpn.app.core.LinkParser
import com.keyvpn.app.core.Links
import com.keyvpn.app.data.Importer
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var clipOffer by mutableStateOf<String?>(null)
    private var lastClip: String? = null
    private var toast by mutableStateOf<String?>(null)

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        handleIntent(intent)
        setContent {
            KeyVpnTheme {
                KeyVpnApp(
                    clipOffer = clipOffer,
                    onClipHandled = { lastClip = clipOffer; clipOffer = null },
                    toast = toast,
                    onToastShown = { toast = null },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** Буфер обмена читается только когда окно в фокусе (требование Android 10+). */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        try {
            val cm = getSystemService(ClipboardManager::class.java)
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()?.trim()
            if (!t.isNullOrEmpty() && t != lastClip && (Links.subscriptionUrl(t) != null || LinkParser.parseAny(t).isNotEmpty())) {
                clipOffer = t
            }
        } catch (_: Exception) {}
    }

    private fun handleIntent(i: Intent?) {
        val text = when (i?.action) {
            Intent.ACTION_VIEW -> i.dataString
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        } ?: return
        AppScope.scope.launch { toast = Importer.import(text).message }
    }
}
