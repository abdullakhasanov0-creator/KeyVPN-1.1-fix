#!/usr/bin/env bash
# Скачивает ядро Xray (libv2ray.aar, 2dust/AndroidLibXrayLite) в app/libs
set -euo pipefail
mkdir -p "$(dirname "$0")/../app/libs"
curl -fL --retry 3 -o "$(dirname "$0")/../app/libs/libv2ray.aar" \
  https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar
ls -lh "$(dirname "$0")/../app/libs/libv2ray.aar"
