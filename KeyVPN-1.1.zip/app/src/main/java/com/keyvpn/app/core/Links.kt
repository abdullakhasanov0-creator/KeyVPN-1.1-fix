package com.keyvpn.app.core

import java.net.URLDecoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Links {
    /** Достаёт URL подписки из http(s)://, happ://add/, v2raytun://import/, v2rayng://install-config?url= и т.п. */
    fun subscriptionUrl(text: String): String? {
        val t = text.trim()
        if (t.isEmpty() || t.any { it.isWhitespace() }) return null
        val lower = t.lowercase()
        for (p in listOf("happ://add/", "v2raytun://import/", "happ://import/")) {
            if (lower.startsWith(p)) return decodeIfNeeded(t.substring(p.length)).takeIf { it.startsWith("http", true) }
        }
        val qi = t.indexOf("url=")
        if (qi > 0 && (lower.startsWith("v2rayng://") || lower.startsWith("clash://") || lower.startsWith("sing-box://"))) {
            return decodeIfNeeded(t.substring(qi + 4).substringBefore('&')).takeIf { it.startsWith("http", true) }
        }
        return if (lower.startsWith("http://") || lower.startsWith("https://")) t else null
    }

    private fun decodeIfNeeded(s: String) = if (s.contains('%')) try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s } else s

    fun sha1(s: String, n: Int = 12): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(n)

    fun hostOf(url: String): String = url.substringAfter("://").substringBefore('/').substringBefore('?')
}

object Fmt {
    fun bytes(n: Long): String {
        val gb = n / 1_073_741_824.0
        return if (gb >= 1) String.format(Locale.US, "%.1f ГБ", gb) else String.format(Locale.US, "%.0f МБ", n / 1_048_576.0)
    }

    /** Заголовок subscription-userinfo -> «Осталось 12.3 ГБ · до 31.12.2026». */
    fun userInfo(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val m = raw.split(';').mapNotNull {
            val p = it.trim().split('=')
            if (p.size == 2) p[0].trim() to (p[1].trim().toLongOrNull() ?: return@mapNotNull null) else null
        }.toMap()
        val parts = ArrayList<String>()
        val total = m["total"] ?: 0L
        if (total > 0) parts += "Осталось " + bytes(maxOf(0L, total - (m["upload"] ?: 0L) - (m["download"] ?: 0L)))
        val exp = m["expire"] ?: 0L
        if (exp > 0) parts += "до " + SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(exp * 1000))
        return parts.joinToString(" · ").ifEmpty { null }
    }

    fun duration(sec: Long): String = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60)
}
