package com.keyvpn.app.vpn

import kotlinx.coroutines.flow.MutableStateFlow

enum class Phase { IDLE, TESTING, CONNECTING, CONNECTED, ERROR }

data class VpnUi(
    val phase: Phase = Phase.IDLE,
    val serverId: String? = null,
    val message: String = "",
    val connectedAt: Long = 0,
)

/** Состояние VPN, общее для сервиса и UI (один процесс). */
object VpnState {
    val ui = MutableStateFlow(VpnUi())
    fun set(phase: Phase, serverId: String? = ui.value.serverId, message: String = "", connectedAt: Long = 0) {
        ui.value = VpnUi(phase, serverId, message, connectedAt)
    }
}
